# Lab1 – HCS12 Assembler LED Test

Dies ist das Repository für Labor 1 im Modul "Computerarchitektur" (Hochschule Esslingen).


## Autoren
Ergün Bickici & Tim Jauch, SS2025